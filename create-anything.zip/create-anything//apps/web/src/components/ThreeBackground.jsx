import { useEffect, useRef } from "react";
import * as THREE from "three";

export default function ThreeBackground() {
  const containerRef = useRef(null);
  const mousePosition = useRef({ x: 0, y: 0 });

  useEffect(() => {
    if (!containerRef.current) return;

    // Scene setup
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      75,
      window.innerWidth / window.innerHeight,
      0.1,
      1000,
    );
    camera.position.z = 5;

    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    containerRef.current.appendChild(renderer.domElement);

    // Create floating geometric shapes
    const geometry1 = new THREE.TorusGeometry(1, 0.3, 16, 100);
    const geometry2 = new THREE.OctahedronGeometry(0.8);
    const geometry3 = new THREE.IcosahedronGeometry(0.7);

    const material = new THREE.MeshPhongMaterial({
      color: 0x3b82f6,
      shininess: 100,
      transparent: true,
      opacity: 0.15,
    });

    const torus = new THREE.Mesh(geometry1, material);
    const octahedron = new THREE.Mesh(geometry2, material.clone());
    const icosahedron = new THREE.Mesh(geometry3, material.clone());

    octahedron.material.color.setHex(0x8b5cf6);
    icosahedron.material.color.setHex(0xec4899);

    torus.position.set(-3, 2, 0);
    octahedron.position.set(3, -2, -1);
    icosahedron.position.set(2, 3, -2);

    scene.add(torus, octahedron, icosahedron);

    // Add ambient light
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambientLight);

    // Add directional light
    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(5, 5, 5);
    scene.add(directionalLight);

    // Create particle system
    const particlesGeometry = new THREE.BufferGeometry();
    const particleCount = 1000;
    const positions = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount * 3; i++) {
      positions[i] = (Math.random() - 0.5) * 20;
    }

    particlesGeometry.setAttribute(
      "position",
      new THREE.BufferAttribute(positions, 3),
    );

    const particlesMaterial = new THREE.PointsMaterial({
      color: 0x6366f1,
      size: 0.02,
      transparent: true,
      opacity: 0.6,
    });

    const particles = new THREE.Points(particlesGeometry, particlesMaterial);
    scene.add(particles);

    // Mouse movement handler
    const handleMouseMove = (event) => {
      mousePosition.current = {
        x: (event.clientX / window.innerWidth) * 2 - 1,
        y: -(event.clientY / window.innerHeight) * 2 + 1,
      };
    };

    window.addEventListener("mousemove", handleMouseMove);

    // Animation loop
    let animationFrameId;
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      // Rotate shapes
      torus.rotation.x += 0.005;
      torus.rotation.y += 0.007;

      octahedron.rotation.x += 0.003;
      octahedron.rotation.y += 0.005;

      icosahedron.rotation.x += 0.004;
      icosahedron.rotation.y += 0.006;

      // Rotate particles slowly
      particles.rotation.y += 0.0005;

      // Follow mouse with parallax effect
      camera.position.x +=
        (mousePosition.current.x * 0.5 - camera.position.x) * 0.05;
      camera.position.y +=
        (mousePosition.current.y * 0.5 - camera.position.y) * 0.05;

      renderer.render(scene, camera);
    };

    animate();

    // Handle resize
    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };

    window.addEventListener("resize", handleResize);

    // Cleanup
    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("resize", handleResize);
      cancelAnimationFrame(animationFrameId);
      if (containerRef.current) {
        containerRef.current.removeChild(renderer.domElement);
      }
      geometry1.dispose();
      geometry2.dispose();
      geometry3.dispose();
      material.dispose();
      particlesGeometry.dispose();
      particlesMaterial.dispose();
      renderer.dispose();
    };
  }, []);

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 -z-10 pointer-events-none"
      style={{ background: "transparent" }}
    />
  );
}
