import { useState, useEffect } from "react";
import { Search, Star, MapPin, ArrowRight } from "lucide-react";
import useUser from "@/utils/useUser";
import ThreeBackground from "@/components/ThreeBackground";

export default function HomePage() {
  const [categories, setCategories] = useState([]);
  const [featuredProviders, setFeaturedProviders] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [location, setLocation] = useState("");
  const { data: user } = useUser();

  useEffect(() => {
    // Fetch categories
    fetch("/api/categories")
      .then((res) => res.json())
      .then((data) => setCategories(data.categories || []))
      .catch((err) => console.error("Error fetching categories:", err));

    // Fetch featured providers
    fetch("/api/providers?featured=true")
      .then((res) => res.json())
      .then((data) => setFeaturedProviders(data.providers || []))
      .catch((err) => console.error("Error fetching providers:", err));
  }, []);

  const handleSearch = () => {
    const params = new URLSearchParams();
    if (searchQuery) params.set("category", searchQuery);
    if (location) params.set("location", location);
    window.location.href = `/browse?${params.toString()}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#f8f9ff] via-white to-[#fff8f8] dark:from-[#0a0a0f] dark:via-[#121212] dark:to-[#1a0f1a] overflow-hidden">
      {/* 3D Background */}
      <ThreeBackground />

      {/* Header with glassmorphism */}
      <header
        className="sticky top-0 z-50 backdrop-blur-xl bg-white/70 dark:bg-[#1E1E1E]/70 border-b border-white/20 dark:border-white/10 shadow-[0_8px_32px_rgba(0,0,0,0.08)]"
        style={{
          fontFamily:
            'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
        }}
      >
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <a
            href="/"
            className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent"
          >
            LocalPro
          </a>
          <nav className="flex items-center gap-6">
            <a
              href="/browse"
              className="text-sm font-medium text-[#7B7B7B] dark:text-[#A0A0A0] hover:text-black dark:hover:text-white transition-all hover:scale-105"
            >
              Find Services
            </a>
            <a
              href="/apply"
              className="text-sm font-medium text-[#7B7B7B] dark:text-[#A0A0A0] hover:text-black dark:hover:text-white transition-all hover:scale-105"
            >
              Become a Provider
            </a>
            {user ? (
              <>
                <a
                  href="/dashboard"
                  className="text-sm font-medium text-[#7B7B7B] dark:text-[#A0A0A0] hover:text-black dark:hover:text-white transition-all hover:scale-105"
                >
                  Dashboard
                </a>
                <a
                  href="/account/logout"
                  className="text-sm font-medium bg-gradient-to-r from-blue-600 to-purple-600 text-white px-4 py-2 rounded-full hover:shadow-[0_8px_24px_rgba(99,102,241,0.4)] transition-all hover:scale-105 hover:-translate-y-0.5"
                >
                  Sign Out
                </a>
              </>
            ) : (
              <>
                <a
                  href="/account/signin"
                  className="text-sm font-medium text-[#7B7B7B] dark:text-[#A0A0A0] hover:text-black dark:hover:text-white transition-all hover:scale-105"
                >
                  Sign In
                </a>
                <a
                  href="/account/signup"
                  className="text-sm font-medium bg-gradient-to-r from-blue-600 to-purple-600 text-white px-4 py-2 rounded-full hover:shadow-[0_8px_24px_rgba(99,102,241,0.4)] transition-all hover:scale-105 hover:-translate-y-0.5"
                >
                  Get Started
                </a>
              </>
            )}
          </nav>
        </div>
      </header>

      {/* Hero Section with 3D effects */}
      <section
        className="pt-20 pb-32 px-6 relative"
        style={{
          fontFamily:
            'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
        }}
      >
        <div className="max-w-7xl mx-auto">
          <div
            className="backdrop-blur-2xl bg-white/60 dark:bg-[#1E1E1E]/60 border border-white/40 dark:border-white/10 rounded-[40px] p-16 shadow-[0_20px_60px_rgba(0,0,0,0.12)] hover:shadow-[0_30px_80px_rgba(0,0,0,0.16)] transition-all duration-500 hover:-translate-y-2"
            style={{
              transform: "perspective(1000px) rotateX(2deg)",
            }}
          >
            <h1
              className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent font-bold leading-[1.05] mb-6 animate-gradient"
              style={{
                fontSize: "clamp(36px, 5vw, 64px)",
              }}
            >
              Find trusted local
              <br />
              service providers
              <br />
              near you
            </h1>
            <p className="text-[#7B7B7B] dark:text-[#A0A0A0] text-lg mb-8 max-w-2xl">
              Connect with verified professionals for plumbing, electrical,
              cleaning, tutoring, and more
            </p>

            {/* Search Bar with depth */}
            <div className="flex flex-col md:flex-row gap-4 max-w-3xl">
              <div className="flex-1">
                <input
                  type="text"
                  placeholder="What service do you need?"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full px-6 py-4 bg-white/80 dark:bg-[#2A2A2A]/80 backdrop-blur-xl border border-white/60 dark:border-[#404040] rounded-xl text-base text-black dark:text-white placeholder-[#A0A0A0] focus:outline-none focus:border-blue-500 dark:focus:border-purple-500 focus:shadow-[0_8px_24px_rgba(99,102,241,0.2)] transition-all"
                />
              </div>
              <div className="flex-1">
                <input
                  type="text"
                  placeholder="Enter your location"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full px-6 py-4 bg-white/80 dark:bg-[#2A2A2A]/80 backdrop-blur-xl border border-white/60 dark:border-[#404040] rounded-xl text-base text-black dark:text-white placeholder-[#A0A0A0] focus:outline-none focus:border-blue-500 dark:focus:border-purple-500 focus:shadow-[0_8px_24px_rgba(99,102,241,0.2)] transition-all"
                />
              </div>
              <button
                onClick={handleSearch}
                className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-4 rounded-xl font-semibold hover:shadow-[0_12px_32px_rgba(99,102,241,0.4)] transition-all flex items-center justify-center gap-2 hover:scale-105 hover:-translate-y-1"
              >
                <Search size={20} />
                Search
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Section with 3D hover effects */}
      <section className="py-20 px-6 relative">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-semibold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-12 text-center">
            Popular Services
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
            {categories.map((category, index) => (
              <a
                key={category.id}
                href={`/browse?category=${encodeURIComponent(category.name)}`}
                className="group backdrop-blur-xl bg-white/60 dark:bg-[#1E1E1E]/60 border border-white/40 dark:border-white/10 rounded-xl p-6 text-center hover:shadow-[0_20px_50px_rgba(99,102,241,0.3)] transition-all duration-500 hover:-translate-y-3 hover:scale-105"
                style={{
                  transform: "perspective(1000px)",
                  animationDelay: `${index * 50}ms`,
                }}
              >
                <div className="text-4xl mb-3 group-hover:scale-125 transition-transform duration-500">
                  {category.icon}
                </div>
                <h3 className="text-base font-semibold text-black dark:text-white mb-1 group-hover:text-blue-600 dark:group-hover:text-purple-400 transition-colors">
                  {category.name}
                </h3>
                <p className="text-xs text-[#7B7B7B] dark:text-[#A0A0A0] line-clamp-2">
                  {category.description}
                </p>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Providers with 3D cards */}
      {featuredProviders.length > 0 && (
        <section className="py-20 px-6 relative">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-4xl font-semibold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-12 text-center">
              Featured Providers
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredProviders.map((provider, index) => (
                <a
                  key={provider.id}
                  href={`/providers/${provider.id}`}
                  className="group backdrop-blur-xl bg-white/60 dark:bg-[#1E1E1E]/60 border border-white/40 dark:border-white/10 rounded-2xl p-6 hover:shadow-[0_24px_60px_rgba(99,102,241,0.25)] transition-all duration-500 hover:-translate-y-4 hover:rotate-1"
                  style={{
                    transform: "perspective(1000px)",
                    animationDelay: `${index * 100}ms`,
                  }}
                >
                  <div className="flex items-start gap-4 mb-4">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center text-2xl overflow-hidden shadow-lg group-hover:scale-110 transition-transform duration-500">
                      {provider.profile_photo ? (
                        <img
                          src={provider.profile_photo}
                          alt={provider.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <span className="text-white font-bold">
                          {provider.name?.charAt(0) || "?"}
                        </span>
                      )}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-black dark:text-white mb-1 group-hover:text-blue-600 dark:group-hover:text-purple-400 transition-colors">
                        {provider.name}
                      </h3>
                      <div className="flex items-center gap-1 mb-2">
                        <Star
                          size={16}
                          className="text-yellow-500 fill-yellow-500"
                        />
                        <span className="text-sm font-medium text-black dark:text-white">
                          {provider.rating || "New"}
                        </span>
                        <span className="text-sm text-[#7B7B7B] dark:text-[#A0A0A0]">
                          ({provider.total_reviews} reviews)
                        </span>
                      </div>
                      <div className="flex items-center gap-1 text-sm text-[#7B7B7B] dark:text-[#A0A0A0]">
                        <MapPin size={14} />
                        {provider.location}
                      </div>
                    </div>
                  </div>
                  <p className="text-sm text-[#7B7B7B] dark:text-[#A0A0A0] line-clamp-2 mb-3">
                    {provider.bio}
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-semibold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                      ${provider.hourly_rate}/hr
                    </span>
                    <span className="text-sm text-black dark:text-white font-medium flex items-center gap-1 group-hover:translate-x-2 transition-transform">
                      View Profile
                      <ArrowRight size={16} />
                    </span>
                  </div>
                </a>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* CTA Section with 3D glow */}
      <section
        className="relative rounded-[24px] mx-6 my-20 overflow-hidden backdrop-blur-2xl bg-gradient-to-br from-blue-50/80 via-purple-50/80 to-pink-50/80 dark:from-blue-950/40 dark:via-purple-950/40 dark:to-pink-950/40 border border-white/40 dark:border-white/10 shadow-[0_24px_60px_rgba(99,102,241,0.2)] hover:shadow-[0_32px_80px_rgba(99,102,241,0.3)] transition-all duration-500 hover:-translate-y-2"
        style={{
          padding: "80px clamp(40px, 8vw, 80px)",
        }}
      >
        <div className="relative z-10 max-w-3xl">
          <h2
            className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent leading-[0.9] mb-8"
            style={{
              fontSize: "clamp(2rem, 4vw, 3.5rem)",
              fontWeight: 700,
            }}
          >
            Ready to offer your
            <br />
            professional services?
          </h2>
          <p className="text-[#7B7B7B] dark:text-[#A0A0A0] text-lg mb-8">
            Join LocalPro today and connect with customers in your area
          </p>
          <a
            href="/apply"
            className="inline-block bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white px-8 py-4 rounded-full transition-all duration-300 font-semibold shadow-[0_12px_32px_rgba(99,102,241,0.3)] hover:shadow-[0_16px_48px_rgba(99,102,241,0.4)] hover:scale-105 hover:-translate-y-1"
          >
            Become a Provider
          </a>
        </div>
      </section>

      <style jsx global>{`
        @keyframes gradient {
          0% {
            background-position: 0% 50%;
          }
          50% {
            background-position: 100% 50%;
          }
          100% {
            background-position: 0% 50%;
          }
        }
        
        .animate-gradient {
          background-size: 200% 200%;
          animation: gradient 8s ease infinite;
        }
      `}</style>
    </div>
  );
}
