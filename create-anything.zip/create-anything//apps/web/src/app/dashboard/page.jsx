import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";
import { Calendar, DollarSign, Star, Clock } from "lucide-react";

export default function DashboardPage() {
  const { data: user, loading: userLoading } = useUser();
  const [profileData, setProfileData] = useState(null);
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!userLoading && !user) {
      window.location.href = "/account/signin?callbackUrl=/dashboard";
    }
  }, [user, userLoading]);

  useEffect(() => {
    if (user) {
      // Fetch user profile data
      fetch("/api/users/me")
        .then((res) => res.json())
        .then((data) => setProfileData(data))
        .catch((err) => console.error("Error fetching profile:", err));

      // Fetch bookings
      fetch("/api/bookings/my")
        .then((res) => res.json())
        .then((data) => {
          setBookings(data.bookings || []);
          setLoading(false);
        })
        .catch((err) => {
          console.error("Error fetching bookings:", err);
          setLoading(false);
        });
    }
  }, [user]);

  const handleStatusChange = async (bookingId, newStatus) => {
    try {
      const res = await fetch(`/api/bookings/${bookingId}/status`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus }),
      });

      if (res.ok) {
        // Refresh bookings
        const data = await fetch("/api/bookings/my").then((r) => r.json());
        setBookings(data.bookings || []);
      }
    } catch (err) {
      console.error("Error updating booking:", err);
    }
  };

  if (userLoading || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        Loading...
      </div>
    );
  }

  const isProvider = profileData?.provider !== null;
  const provider = profileData?.provider;

  return (
    <div
      className="min-h-screen bg-white dark:bg-[#121212]"
      style={{
        fontFamily:
          'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
      }}
    >
      {/* Header */}
      <header className="bg-white dark:bg-[#1E1E1E] border-b border-[#E9E9E9] dark:border-[#333333]">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <a href="/" className="text-2xl font-bold text-black dark:text-white">
            LocalPro
          </a>
          <nav className="flex items-center gap-6">
            <a
              href="/"
              className="text-sm font-medium text-[#7B7B7B] dark:text-[#A0A0A0] hover:text-black dark:hover:text-white"
            >
              Home
            </a>
            <a
              href="/account/logout"
              className="text-sm font-medium bg-black dark:bg-white text-white dark:text-black px-4 py-2 rounded-full"
            >
              Sign Out
            </a>
          </nav>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="mb-8">
          <h1 className="text-4xl font-semibold text-black dark:text-white mb-2">
            Welcome, {user?.name}
          </h1>
          <p className="text-[#7B7B7B] dark:text-[#A0A0A0]">
            {isProvider
              ? "Manage your services and bookings"
              : "Manage your bookings"}
          </p>
        </div>

        {/* Provider Stats */}
        {isProvider && provider && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
            <div className="bg-white dark:bg-[#1E1E1E] border border-[#E6E6E6] dark:border-[#333333] rounded-2xl p-6">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center">
                  <Star
                    size={20}
                    className="text-blue-600 dark:text-blue-400"
                  />
                </div>
                <span className="text-sm text-[#7B7B7B] dark:text-[#A0A0A0]">
                  Rating
                </span>
              </div>
              <div className="text-2xl font-semibold text-black dark:text-white">
                {provider.rating > 0 ? provider.rating.toFixed(1) : "New"}
              </div>
              <div className="text-xs text-[#7B7B7B] dark:text-[#A0A0A0]">
                {provider.total_reviews} reviews
              </div>
            </div>

            <div className="bg-white dark:bg-[#1E1E1E] border border-[#E6E6E6] dark:border-[#333333] rounded-2xl p-6">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-green-100 dark:bg-green-900/30 rounded-lg flex items-center justify-center">
                  <DollarSign
                    size={20}
                    className="text-green-600 dark:text-green-400"
                  />
                </div>
                <span className="text-sm text-[#7B7B7B] dark:text-[#A0A0A0]">
                  Total Earnings
                </span>
              </div>
              <div className="text-2xl font-semibold text-black dark:text-white">
                ${provider.total_earnings || 0}
              </div>
            </div>

            <div className="bg-white dark:bg-[#1E1E1E] border border-[#E6E6E6] dark:border-[#333333] rounded-2xl p-6">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-purple-100 dark:bg-purple-900/30 rounded-lg flex items-center justify-center">
                  <Calendar
                    size={20}
                    className="text-purple-600 dark:text-purple-400"
                  />
                </div>
                <span className="text-sm text-[#7B7B7B] dark:text-[#A0A0A0]">
                  Status
                </span>
              </div>
              <div className="text-lg font-semibold text-black dark:text-white capitalize">
                {provider.verification_status}
              </div>
            </div>

            <div className="bg-white dark:bg-[#1E1E1E] border border-[#E6E6E6] dark:border-[#333333] rounded-2xl p-6">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-orange-100 dark:bg-orange-900/30 rounded-lg flex items-center justify-center">
                  <Clock
                    size={20}
                    className="text-orange-600 dark:text-orange-400"
                  />
                </div>
                <span className="text-sm text-[#7B7B7B] dark:text-[#A0A0A0]">
                  Hourly Rate
                </span>
              </div>
              <div className="text-2xl font-semibold text-black dark:text-white">
                ${provider.hourly_rate}
              </div>
            </div>
          </div>
        )}

        {/* Not a provider CTA */}
        {!isProvider && (
          <div className="bg-gradient-to-r from-[#FFFCE8] to-[#F7F4D1] dark:from-[#2A2A1A] dark:to-[#1E1E1E] border border-[#E6E6E6] dark:border-[#333333] rounded-2xl p-8 mb-12">
            <h3 className="text-2xl font-semibold text-black dark:text-white mb-2">
              Want to offer your services?
            </h3>
            <p className="text-[#7B7B7B] dark:text-[#A0A0A0] mb-4">
              Become a verified provider and start earning money from your
              skills
            </p>
            <a
              href="/apply"
              className="inline-block bg-black dark:bg-white text-white dark:text-black px-6 py-3 rounded-full font-semibold hover:bg-[#1a1a1a] dark:hover:bg-[#F0F0F0]"
            >
              Apply Now
            </a>
          </div>
        )}

        {/* Bookings */}
        <div>
          <h2 className="text-2xl font-semibold text-black dark:text-white mb-6">
            {isProvider ? "Your Bookings" : "My Bookings"}
          </h2>

          {bookings.length === 0 ? (
            <div className="bg-white dark:bg-[#1E1E1E] border border-[#E6E6E6] dark:border-[#333333] rounded-2xl p-12 text-center">
              <p className="text-[#7B7B7B] dark:text-[#A0A0A0]">
                No bookings yet
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {bookings.map((booking) => (
                <div
                  key={booking.id}
                  className="bg-white dark:bg-[#1E1E1E] border border-[#E6E6E6] dark:border-[#333333] rounded-2xl p-6"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-lg font-semibold text-black dark:text-white mb-1">
                        {booking.service}
                      </h3>
                      <p className="text-sm text-[#7B7B7B] dark:text-[#A0A0A0]">
                        {isProvider
                          ? `Customer: ${booking.customer_name}`
                          : `Provider: ${booking.provider_name}`}
                      </p>
                    </div>
                    <span
                      className={`px-4 py-2 rounded-full text-sm font-medium ${
                        booking.status === "completed"
                          ? "bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400"
                          : booking.status === "accepted"
                            ? "bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400"
                            : booking.status === "pending"
                              ? "bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400"
                              : "bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400"
                      }`}
                    >
                      {booking.status}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                    <div>
                      <div className="text-xs text-[#7B7B7B] dark:text-[#A0A0A0] mb-1">
                        Date
                      </div>
                      <div className="text-sm font-medium text-black dark:text-white">
                        {new Date(booking.booking_date).toLocaleDateString()}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-[#7B7B7B] dark:text-[#A0A0A0] mb-1">
                        Time
                      </div>
                      <div className="text-sm font-medium text-black dark:text-white">
                        {booking.booking_time}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-[#7B7B7B] dark:text-[#A0A0A0] mb-1">
                        Price
                      </div>
                      <div className="text-sm font-medium text-black dark:text-white">
                        ${booking.price}
                      </div>
                    </div>
                  </div>

                  {isProvider && booking.status === "pending" && (
                    <div className="flex gap-3 pt-4 border-t border-[#E6E6E6] dark:border-[#404040]">
                      <button
                        onClick={() =>
                          handleStatusChange(booking.id, "accepted")
                        }
                        className="px-4 py-2 bg-black dark:bg-white text-white dark:text-black rounded-lg font-medium hover:bg-[#1a1a1a] dark:hover:bg-[#F0F0F0]"
                      >
                        Accept
                      </button>
                      <button
                        onClick={() =>
                          handleStatusChange(booking.id, "rejected")
                        }
                        className="px-4 py-2 bg-red-600 dark:bg-red-700 text-white rounded-lg font-medium hover:bg-red-700 dark:hover:bg-red-800"
                      >
                        Reject
                      </button>
                    </div>
                  )}

                  {isProvider && booking.status === "accepted" && (
                    <div className="pt-4 border-t border-[#E6E6E6] dark:border-[#404040]">
                      <button
                        onClick={() =>
                          handleStatusChange(booking.id, "completed")
                        }
                        className="px-4 py-2 bg-green-600 dark:bg-green-700 text-white rounded-lg font-medium hover:bg-green-700 dark:hover:bg-green-800"
                      >
                        Mark as Completed
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
