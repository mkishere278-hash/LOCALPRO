import { useState } from "react";
import useAuth from "@/utils/useAuth";

export default function SignInPage() {
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const { signInWithCredentials } = useAuth();

  const onSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    if (!email || !password) {
      setError("Please fill in all fields");
      setLoading(false);
      return;
    }

    try {
      await signInWithCredentials({
        email,
        password,
        callbackUrl: "/",
        redirect: true,
      });
    } catch (err) {
      setError("Invalid email or password");
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-white dark:bg-[#121212] px-6">
      <form
        noValidate
        onSubmit={onSubmit}
        className="w-full max-w-md bg-white dark:bg-[#1E1E1E] border border-[#E6E6E6] dark:border-[#333333] rounded-2xl p-10 shadow-[0_8px_16px_rgba(0,0,0,0.06)] dark:shadow-[0_8px_16px_rgba(0,0,0,0.2)]"
        style={{
          fontFamily:
            'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
        }}
      >
        <h1 className="mb-2 text-center text-3xl font-semibold text-black dark:text-white">
          Welcome Back
        </h1>
        <p className="mb-8 text-center text-sm text-[#7B7B7B] dark:text-[#A0A0A0]">
          Sign in to your LocalPro account
        </p>

        <div className="space-y-5">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-[#343434] dark:text-[#E0E0E0]">
              Email
            </label>
            <input
              required
              name="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email"
              className="w-full px-4 py-3 bg-white dark:bg-[#2A2A2A] border border-[#E6E6E6] dark:border-[#404040] rounded-lg text-base text-black dark:text-white placeholder-[#A0A0A0] focus:outline-none focus:border-black dark:focus:border-white transition-colors"
            />
          </div>
          <div className="space-y-2">
            <label className="block text-sm font-medium text-[#343434] dark:text-[#E0E0E0]">
              Password
            </label>
            <input
              required
              name="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 bg-white dark:bg-[#2A2A2A] border border-[#E6E6E6] dark:border-[#404040] rounded-lg text-base text-black dark:text-white placeholder-[#A0A0A0] focus:outline-none focus:border-black dark:focus:border-white transition-colors"
              placeholder="Enter your password"
            />
          </div>

          {error && (
            <div className="rounded-lg bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 p-3 text-sm text-red-600 dark:text-red-400">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-black dark:bg-white hover:bg-[#1a1a1a] dark:hover:bg-[#F0F0F0] active:bg-[#000000] dark:active:bg-[#E0E0E0] text-white dark:text-black px-6 py-3 rounded-full transition-all duration-150 ease-out font-semibold text-base shadow-[0_4px_12px_rgba(0,0,0,0.15)] active:scale-[0.98] disabled:opacity-50"
          >
            {loading ? "Signing in..." : "Sign In"}
          </button>
          <p className="text-center text-sm text-[#7B7B7B] dark:text-[#A0A0A0]">
            Don't have an account?{" "}
            <a
              href="/account/signup"
              className="text-black dark:text-white font-medium hover:underline"
            >
              Sign up
            </a>
          </p>
        </div>
      </form>
    </div>
  );
}
