import useAuth from "@/utils/useAuth";

export default function LogoutPage() {
  const { signOut } = useAuth();

  const handleSignOut = async () => {
    await signOut({
      callbackUrl: "/",
      redirect: true,
    });
  };

  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-white dark:bg-[#121212] px-6">
      <div
        className="w-full max-w-md bg-white dark:bg-[#1E1E1E] border border-[#E6E6E6] dark:border-[#333333] rounded-2xl p-10 shadow-[0_8px_16px_rgba(0,0,0,0.06)] dark:shadow-[0_8px_16px_rgba(0,0,0,0.2)]"
        style={{
          fontFamily:
            'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
        }}
      >
        <h1 className="mb-8 text-center text-3xl font-semibold text-black dark:text-white">
          Sign Out
        </h1>

        <button
          onClick={handleSignOut}
          className="w-full bg-black dark:bg-white hover:bg-[#1a1a1a] dark:hover:bg-[#F0F0F0] active:bg-[#000000] dark:active:bg-[#E0E0E0] text-white dark:text-black px-6 py-3 rounded-full transition-all duration-150 ease-out font-semibold text-base shadow-[0_4px_12px_rgba(0,0,0,0.15)] active:scale-[0.98]"
        >
          Sign Out
        </button>
      </div>
    </div>
  );
}
