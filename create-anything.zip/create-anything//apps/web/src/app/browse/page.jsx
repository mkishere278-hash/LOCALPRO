import { useState, useEffect } from "react";
import { Filter, Star, MapPin } from "lucide-react";

export default function BrowsePage() {
  const [providers, setProviders] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    category: "",
    location: "",
    minRating: "",
  });

  useEffect(() => {
    // Get filters from URL
    const params = new URLSearchParams(window.location.search);
    const category = params.get("category") || "";
    const location = params.get("location") || "";

    setFilters({ category, location, minRating: "" });

    // Fetch categories
    fetch("/api/categories")
      .then((res) => res.json())
      .then((data) => setCategories(data.categories || []))
      .catch((err) => console.error("Error fetching categories:", err));

    // Fetch providers
    fetchProviders({ category, location });
  }, []);

  const fetchProviders = (currentFilters) => {
    setLoading(true);
    const params = new URLSearchParams();
    if (currentFilters.category)
      params.set("category", currentFilters.category);
    if (currentFilters.location)
      params.set("location", currentFilters.location);
    if (currentFilters.minRating)
      params.set("minRating", currentFilters.minRating);

    fetch(`/api/providers?${params.toString()}`)
      .then((res) => res.json())
      .then((data) => {
        setProviders(data.providers || []);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Error fetching providers:", err);
        setLoading(false);
      });
  };

  const handleFilterChange = (key, value) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    fetchProviders(newFilters);
  };

  return (
    <div
      className="min-h-screen bg-white dark:bg-[#121212]"
      style={{
        fontFamily:
          'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
      }}
    >
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white dark:bg-[#1E1E1E] border-b border-[#E9E9E9] dark:border-[#333333]">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <a href="/" className="text-2xl font-bold text-black dark:text-white">
            LocalPro
          </a>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-12">
        <h1 className="text-4xl font-semibold text-black dark:text-white mb-8">
          Browse Service Providers
        </h1>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          <aside className="w-full lg:w-64 flex-shrink-0">
            <div className="bg-white dark:bg-[#1E1E1E] border border-[#E6E6E6] dark:border-[#333333] rounded-2xl p-6 sticky top-24">
              <div className="flex items-center gap-2 mb-6">
                <Filter size={20} />
                <h2 className="text-lg font-semibold text-black dark:text-white">
                  Filters
                </h2>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-black dark:text-white mb-2">
                    Category
                  </label>
                  <select
                    value={filters.category}
                    onChange={(e) =>
                      handleFilterChange("category", e.target.value)
                    }
                    className="w-full px-4 py-2 bg-white dark:bg-[#2A2A2A] border border-[#E6E6E6] dark:border-[#404040] rounded-lg text-black dark:text-white focus:outline-none focus:border-black dark:focus:border-white"
                  >
                    <option value="">All Categories</option>
                    {categories.map((cat) => (
                      <option key={cat.id} value={cat.name}>
                        {cat.icon} {cat.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-black dark:text-white mb-2">
                    Location
                  </label>
                  <input
                    type="text"
                    value={filters.location}
                    onChange={(e) =>
                      handleFilterChange("location", e.target.value)
                    }
                    placeholder="Enter location"
                    className="w-full px-4 py-2 bg-white dark:bg-[#2A2A2A] border border-[#E6E6E6] dark:border-[#404040] rounded-lg text-black dark:text-white focus:outline-none focus:border-black dark:focus:border-white"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-black dark:text-white mb-2">
                    Minimum Rating
                  </label>
                  <select
                    value={filters.minRating}
                    onChange={(e) =>
                      handleFilterChange("minRating", e.target.value)
                    }
                    className="w-full px-4 py-2 bg-white dark:bg-[#2A2A2A] border border-[#E6E6E6] dark:border-[#404040] rounded-lg text-black dark:text-white focus:outline-none focus:border-black dark:focus:border-white"
                  >
                    <option value="">Any Rating</option>
                    <option value="4">4+ Stars</option>
                    <option value="4.5">4.5+ Stars</option>
                  </select>
                </div>
              </div>
            </div>
          </aside>

          {/* Providers Grid */}
          <main className="flex-1">
            {loading ? (
              <div className="text-center py-20">
                <div className="text-lg text-[#7B7B7B] dark:text-[#A0A0A0]">
                  Loading providers...
                </div>
              </div>
            ) : providers.length === 0 ? (
              <div className="text-center py-20">
                <div className="text-lg text-[#7B7B7B] dark:text-[#A0A0A0]">
                  No providers found matching your criteria
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {providers.map((provider) => (
                  <a
                    key={provider.id}
                    href={`/providers/${provider.id}`}
                    className="bg-white dark:bg-[#1E1E1E] border border-[#E6E6E6] dark:border-[#333333] rounded-2xl p-6 hover:shadow-xl transition-all hover:-translate-y-1"
                  >
                    <div className="flex items-start gap-4 mb-4">
                      <div className="w-16 h-16 rounded-full bg-[#E6E6E6] dark:bg-[#404040] flex items-center justify-center text-2xl font-semibold overflow-hidden flex-shrink-0">
                        {provider.profile_photo ? (
                          <img
                            src={provider.profile_photo}
                            alt={provider.name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          provider.name?.charAt(0) || "?"
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="text-lg font-semibold text-black dark:text-white mb-1 truncate">
                          {provider.name}
                        </h3>
                        <div className="flex items-center gap-1 mb-2">
                          <Star
                            size={16}
                            className="text-yellow-500 fill-yellow-500"
                          />
                          <span className="text-sm font-medium text-black dark:text-white">
                            {provider.rating > 0
                              ? provider.rating.toFixed(1)
                              : "New"}
                          </span>
                          <span className="text-sm text-[#7B7B7B] dark:text-[#A0A0A0]">
                            ({provider.total_reviews})
                          </span>
                        </div>
                        <div className="flex items-center gap-1 text-sm text-[#7B7B7B] dark:text-[#A0A0A0]">
                          <MapPin size={14} />
                          <span className="truncate">{provider.location}</span>
                        </div>
                      </div>
                    </div>

                    <p className="text-sm text-[#7B7B7B] dark:text-[#A0A0A0] line-clamp-2 mb-3">
                      {provider.bio}
                    </p>

                    {provider.services && provider.services.length > 0 && (
                      <div className="flex flex-wrap gap-2 mb-3">
                        {provider.services.slice(0, 3).map((service, idx) => (
                          <span
                            key={idx}
                            className="px-3 py-1 bg-[#F5F5F5] dark:bg-[#2A2A2A] text-xs font-medium text-black dark:text-white rounded-full"
                          >
                            {service}
                          </span>
                        ))}
                      </div>
                    )}

                    <div className="flex items-center justify-between pt-3 border-t border-[#E6E6E6] dark:border-[#404040]">
                      <span className="text-lg font-semibold text-black dark:text-white">
                        ${provider.hourly_rate}/hr
                      </span>
                      <span className="text-sm text-black dark:text-white font-medium">
                        View Profile →
                      </span>
                    </div>
                  </a>
                ))}
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  );
}
