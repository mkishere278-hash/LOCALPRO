import { useState, useEffect } from "react";
import { Upload } from "lucide-react";
import useUser from "@/utils/useUser";
import useUpload from "@/utils/useUpload";

export default function ApplyPage() {
  const { data: user, loading: userLoading } = useUser();
  const [upload] = useUpload();
  const [categories, setCategories] = useState([]);
  const [formData, setFormData] = useState({
    bio: "",
    hourlyRate: "",
    services: [],
    location: "",
    profilePhoto: "",
  });
  const [uploading, setUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    if (!userLoading && !user) {
      window.location.href = "/account/signin?callbackUrl=/apply";
    }
  }, [user, userLoading]);

  useEffect(() => {
    fetch("/api/categories")
      .then((res) => res.json())
      .then((data) => setCategories(data.categories || []))
      .catch((err) => console.error("Error fetching categories:", err));
  }, []);

  const handlePhotoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    const result = await upload({ reactNativeAsset: { file } });
    if (result.error) {
      setError(result.error);
    } else {
      setFormData({ ...formData, profilePhoto: result.url });
    }
    setUploading(false);
  };

  const handleServiceToggle = (serviceName) => {
    setFormData({
      ...formData,
      services: formData.services.includes(serviceName)
        ? formData.services.filter((s) => s !== serviceName)
        : [...formData.services, serviceName],
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);

    if (
      !formData.bio ||
      !formData.hourlyRate ||
      formData.services.length === 0 ||
      !formData.location
    ) {
      setError("Please fill in all required fields");
      setSubmitting(false);
      return;
    }

    try {
      const res = await fetch("/api/providers/apply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Failed to submit application");
      }

      setSuccess(true);
      setTimeout(() => {
        window.location.href = "/dashboard";
      }, 2000);
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  if (userLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        Loading...
      </div>
    );
  }

  return (
    <div
      className="min-h-screen bg-white dark:bg-[#121212] py-12 px-6"
      style={{
        fontFamily:
          'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
      }}
    >
      <div className="max-w-3xl mx-auto">
        <div className="mb-8">
          <a
            href="/"
            className="text-sm text-[#7B7B7B] dark:text-[#A0A0A0] hover:text-black dark:hover:text-white"
          >
            ← Back to Home
          </a>
        </div>

        <div className="bg-white dark:bg-[#1E1E1E] border border-[#E6E6E6] dark:border-[#333333] rounded-2xl p-8 md:p-12">
          <h1 className="text-3xl font-semibold text-black dark:text-white mb-2">
            Become a Provider
          </h1>
          <p className="text-[#7B7B7B] dark:text-[#A0A0A0] mb-8">
            Join LocalPro and start offering your services to local customers
          </p>

          {success ? (
            <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4 text-green-700 dark:text-green-400">
              Application submitted successfully! Redirecting to dashboard...
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Profile Photo */}
              <div>
                <label className="block text-sm font-medium text-black dark:text-white mb-2">
                  Profile Photo (Optional)
                </label>
                <div className="flex items-center gap-4">
                  <div className="w-24 h-24 rounded-full bg-[#E6E6E6] dark:bg-[#404040] flex items-center justify-center overflow-hidden">
                    {formData.profilePhoto ? (
                      <img
                        src={formData.profilePhoto}
                        alt="Profile"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <Upload size={32} className="text-[#A0A0A0]" />
                    )}
                  </div>
                  <label className="cursor-pointer bg-black dark:bg-white text-white dark:text-black px-4 py-2 rounded-lg hover:bg-[#1a1a1a] dark:hover:bg-[#F0F0F0] font-medium">
                    {uploading ? "Uploading..." : "Upload Photo"}
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handlePhotoUpload}
                      className="hidden"
                      disabled={uploading}
                    />
                  </label>
                </div>
              </div>

              {/* Bio */}
              <div>
                <label className="block text-sm font-medium text-black dark:text-white mb-2">
                  Bio *
                </label>
                <textarea
                  value={formData.bio}
                  onChange={(e) =>
                    setFormData({ ...formData, bio: e.target.value })
                  }
                  rows={4}
                  placeholder="Tell customers about your experience and expertise..."
                  className="w-full px-4 py-3 bg-white dark:bg-[#2A2A2A] border border-[#E6E6E6] dark:border-[#404040] rounded-lg text-black dark:text-white placeholder-[#A0A0A0] focus:outline-none focus:border-black dark:focus:border-white"
                  required
                />
              </div>

              {/* Hourly Rate */}
              <div>
                <label className="block text-sm font-medium text-black dark:text-white mb-2">
                  Hourly Rate (USD) *
                </label>
                <input
                  type="number"
                  value={formData.hourlyRate}
                  onChange={(e) =>
                    setFormData({ ...formData, hourlyRate: e.target.value })
                  }
                  placeholder="50"
                  min="0"
                  step="0.01"
                  className="w-full px-4 py-3 bg-white dark:bg-[#2A2A2A] border border-[#E6E6E6] dark:border-[#404040] rounded-lg text-black dark:text-white placeholder-[#A0A0A0] focus:outline-none focus:border-black dark:focus:border-white"
                  required
                />
              </div>

              {/* Services */}
              <div>
                <label className="block text-sm font-medium text-black dark:text-white mb-3">
                  Services Offered * (Select all that apply)
                </label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {categories.map((cat) => (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => handleServiceToggle(cat.name)}
                      className={`px-4 py-3 rounded-lg border-2 text-left transition-all ${
                        formData.services.includes(cat.name)
                          ? "border-black dark:border-white bg-black dark:bg-white text-white dark:text-black"
                          : "border-[#E6E6E6] dark:border-[#404040] bg-white dark:bg-[#2A2A2A] text-black dark:text-white hover:border-black dark:hover:border-white"
                      }`}
                    >
                      <div className="text-lg mb-1">{cat.icon}</div>
                      <div className="text-sm font-medium">{cat.name}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Location */}
              <div>
                <label className="block text-sm font-medium text-black dark:text-white mb-2">
                  Location *
                </label>
                <input
                  type="text"
                  value={formData.location}
                  onChange={(e) =>
                    setFormData({ ...formData, location: e.target.value })
                  }
                  placeholder="City, State"
                  className="w-full px-4 py-3 bg-white dark:bg-[#2A2A2A] border border-[#E6E6E6] dark:border-[#404040] rounded-lg text-black dark:text-white placeholder-[#A0A0A0] focus:outline-none focus:border-black dark:focus:border-white"
                  required
                />
              </div>

              {error && (
                <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4 text-red-600 dark:text-red-400">
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={submitting}
                className="w-full bg-black dark:bg-white text-white dark:text-black px-6 py-4 rounded-xl font-semibold hover:bg-[#1a1a1a] dark:hover:bg-[#F0F0F0] transition-all disabled:opacity-50"
              >
                {submitting ? "Submitting..." : "Submit Application"}
              </button>

              <p className="text-sm text-[#7B7B7B] dark:text-[#A0A0A0] text-center">
                Your application will be reviewed and you'll be notified once
                approved
              </p>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
