import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const customerId = session.user.id;
    const body = await request.json();
    const { providerId, service, bookingDate, bookingTime, price, notes } =
      body;

    if (!providerId || !service || !bookingDate || !bookingTime || !price) {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }

    const result = await sql`
      INSERT INTO bookings (
        customer_id, provider_id, service, booking_date, 
        booking_time, price, notes, status
      )
      VALUES (
        ${customerId}, ${providerId}, ${service}, ${bookingDate},
        ${bookingTime}, ${price}, ${notes || null}, 'pending'
      )
      RETURNING *
    `;

    return Response.json({ booking: result[0] }, { status: 201 });
  } catch (error) {
    console.error("Error creating booking:", error);
    return Response.json(
      { error: "Failed to create booking" },
      { status: 500 },
    );
  }
}
