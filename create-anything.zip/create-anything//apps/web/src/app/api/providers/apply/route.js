import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;
    const body = await request.json();
    const {
      bio,
      hourlyRate,
      services,
      location,
      profilePhoto,
      verificationDocuments,
    } = body;

    if (!bio || !hourlyRate || !services || !location) {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }

    // Check if user is already a provider
    const existing = await sql`
      SELECT id FROM providers WHERE user_id = ${userId}
    `;

    if (existing.length > 0) {
      return Response.json(
        { error: "You are already a provider" },
        { status: 400 },
      );
    }

    const result = await sql`
      INSERT INTO providers (
        user_id, bio, hourly_rate, services, location, 
        profile_photo, verification_documents, verification_status
      )
      VALUES (
        ${userId}, ${bio}, ${hourlyRate}, ${services}, ${location},
        ${profilePhoto || null}, ${verificationDocuments || []}, 'pending'
      )
      RETURNING *
    `;

    return Response.json({ provider: result[0] }, { status: 201 });
  } catch (error) {
    console.error("Error applying as provider:", error);
    return Response.json(
      { error: "Failed to apply as provider" },
      { status: 500 },
    );
  }
}
