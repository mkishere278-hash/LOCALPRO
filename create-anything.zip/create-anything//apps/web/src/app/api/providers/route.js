import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get("category");
    const location = searchParams.get("location");
    const minRating = searchParams.get("minRating");
    const featured = searchParams.get("featured");

    let query = `
      SELECT 
        p.id,
        p.user_id,
        p.bio,
        p.hourly_rate,
        p.services,
        p.profile_photo,
        p.location,
        p.rating,
        p.total_reviews,
        p.is_featured,
        p.subscription_tier,
        u.name,
        u.email
      FROM providers p
      JOIN auth_users u ON p.user_id = u.id
      WHERE p.verification_status = 'approved'
    `;

    const values = [];
    let paramCount = 0;

    if (category) {
      paramCount++;
      query += ` AND $${paramCount} = ANY(p.services)`;
      values.push(category);
    }

    if (location) {
      paramCount++;
      query += ` AND LOWER(p.location) LIKE LOWER($${paramCount})`;
      values.push(`%${location}%`);
    }

    if (minRating) {
      paramCount++;
      query += ` AND p.rating >= $${paramCount}`;
      values.push(parseFloat(minRating));
    }

    if (featured === "true") {
      query += ` AND p.is_featured = true`;
    }

    query += ` ORDER BY p.is_featured DESC, p.rating DESC, p.total_reviews DESC`;

    const providers = await sql(query, values);

    return Response.json({ providers });
  } catch (error) {
    console.error("Error fetching providers:", error);
    return Response.json(
      { error: "Failed to fetch providers" },
      { status: 500 },
    );
  }
}
