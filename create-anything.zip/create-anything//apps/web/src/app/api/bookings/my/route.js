import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET() {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;

    // Check if user is a provider
    const providerCheck = await sql`
      SELECT id FROM providers WHERE user_id = ${userId}
    `;

    let bookings;
    if (providerCheck.length > 0) {
      // User is a provider, get bookings where they are the provider
      const providerId = providerCheck[0].id;
      bookings = await sql`
        SELECT 
          b.*,
          c.name as customer_name,
          c.email as customer_email
        FROM bookings b
        JOIN auth_users c ON b.customer_id = c.id
        WHERE b.provider_id = ${providerId}
        ORDER BY b.booking_date DESC, b.booking_time DESC
      `;
    } else {
      // User is a customer, get their bookings
      bookings = await sql`
        SELECT 
          b.*,
          p.bio,
          p.profile_photo,
          u.name as provider_name,
          u.email as provider_email
        FROM bookings b
        JOIN providers p ON b.provider_id = p.id
        JOIN auth_users u ON p.user_id = u.id
        WHERE b.customer_id = ${userId}
        ORDER BY b.booking_date DESC, b.booking_time DESC
      `;
    }

    return Response.json({ bookings, isProvider: providerCheck.length > 0 });
  } catch (error) {
    console.error("Error fetching bookings:", error);
    return Response.json(
      { error: "Failed to fetch bookings" },
      { status: 500 },
    );
  }
}
