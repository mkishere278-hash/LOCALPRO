import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function PUT(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Check if user is admin (you'll need to add role column)
    const userCheck = await sql`
      SELECT role FROM auth_users WHERE id = ${session.user.id}
    `;

    if (!userCheck[0] || userCheck[0].role !== "admin") {
      return Response.json(
        { error: "Forbidden - Admin only" },
        { status: 403 },
      );
    }

    const body = await request.json();
    const { providerId, status } = body;

    if (!providerId || !status || !["approved", "rejected"].includes(status)) {
      return Response.json({ error: "Invalid request" }, { status: 400 });
    }

    const result = await sql`
      UPDATE providers
      SET verification_status = ${status}, updated_at = CURRENT_TIMESTAMP
      WHERE id = ${providerId}
      RETURNING *
    `;

    if (result.length === 0) {
      return Response.json({ error: "Provider not found" }, { status: 404 });
    }

    return Response.json({ provider: result[0] });
  } catch (error) {
    console.error("Error verifying provider:", error);
    return Response.json(
      { error: "Failed to verify provider" },
      { status: 500 },
    );
  }
}
