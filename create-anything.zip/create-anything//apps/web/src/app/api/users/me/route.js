import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET() {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;

    const user = await sql`
      SELECT id, name, email, image, role
      FROM auth_users
      WHERE id = ${userId}
    `;

    if (user.length === 0) {
      return Response.json({ error: "User not found" }, { status: 404 });
    }

    // Check if user is a provider
    const provider = await sql`
      SELECT * FROM providers WHERE user_id = ${userId}
    `;

    return Response.json({
      user: user[0],
      provider: provider.length > 0 ? provider[0] : null,
    });
  } catch (error) {
    console.error("Error fetching user:", error);
    return Response.json({ error: "Failed to fetch user" }, { status: 500 });
  }
}
