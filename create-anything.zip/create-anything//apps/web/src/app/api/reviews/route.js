import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const customerId = session.user.id;
    const body = await request.json();
    const { bookingId, rating, comment } = body;

    if (!bookingId || !rating || rating < 1 || rating > 5) {
      return Response.json({ error: "Invalid request" }, { status: 400 });
    }

    // Check if booking exists and belongs to customer
    const booking = await sql`
      SELECT * FROM bookings
      WHERE id = ${bookingId} AND customer_id = ${customerId} AND status = 'completed'
    `;

    if (booking.length === 0) {
      return Response.json(
        { error: "Booking not found or not completed" },
        { status: 404 },
      );
    }

    // Check if review already exists
    const existing = await sql`
      SELECT id FROM reviews WHERE booking_id = ${bookingId}
    `;

    if (existing.length > 0) {
      return Response.json(
        { error: "Review already exists for this booking" },
        { status: 400 },
      );
    }

    const providerId = booking[0].provider_id;

    // Insert review
    const review = await sql`
      INSERT INTO reviews (booking_id, provider_id, customer_id, rating, comment)
      VALUES (${bookingId}, ${providerId}, ${customerId}, ${rating}, ${comment || null})
      RETURNING *
    `;

    // Update provider rating
    const stats = await sql`
      SELECT AVG(rating)::numeric(3,2) as avg_rating, COUNT(*) as total_reviews
      FROM reviews
      WHERE provider_id = ${providerId}
    `;

    await sql`
      UPDATE providers
      SET rating = ${stats[0].avg_rating}, total_reviews = ${stats[0].total_reviews}
      WHERE id = ${providerId}
    `;

    return Response.json({ review: review[0] }, { status: 201 });
  } catch (error) {
    console.error("Error creating review:", error);
    return Response.json({ error: "Failed to create review" }, { status: 500 });
  }
}
