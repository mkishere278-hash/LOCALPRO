import sql from "@/app/api/utils/sql";

export async function GET(request, { params }) {
  try {
    const { id } = params;

    const providers = await sql`
      SELECT 
        p.*,
        u.name,
        u.email
      FROM providers p
      JOIN auth_users u ON p.user_id = u.id
      WHERE p.id = ${id}
      LIMIT 1
    `;

    if (providers.length === 0) {
      return Response.json({ error: "Provider not found" }, { status: 404 });
    }

    return Response.json({ provider: providers[0] });
  } catch (error) {
    console.error("Error fetching provider:", error);
    return Response.json(
      { error: "Failed to fetch provider" },
      { status: 500 },
    );
  }
}
