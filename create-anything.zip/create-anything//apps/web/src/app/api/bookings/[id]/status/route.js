import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function PUT(request, { params }) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id } = params;
    const body = await request.json();
    const { status } = body;

    if (
      !status ||
      !["accepted", "rejected", "completed", "cancelled"].includes(status)
    ) {
      return Response.json({ error: "Invalid status" }, { status: 400 });
    }

    // Get booking to check permissions
    const booking = await sql`
      SELECT b.*, p.user_id as provider_user_id
      FROM bookings b
      JOIN providers p ON b.provider_id = p.id
      WHERE b.id = ${id}
    `;

    if (booking.length === 0) {
      return Response.json({ error: "Booking not found" }, { status: 404 });
    }

    const userId = session.user.id;
    const isProvider = booking[0].provider_user_id === userId;
    const isCustomer = booking[0].customer_id === userId;

    if (!isProvider && !isCustomer) {
      return Response.json({ error: "Forbidden" }, { status: 403 });
    }

    // Update booking status
    const result = await sql`
      UPDATE bookings
      SET status = ${status}, updated_at = CURRENT_TIMESTAMP
      WHERE id = ${id}
      RETURNING *
    `;

    // If booking completed, update provider earnings
    if (status === "completed") {
      await sql`
        UPDATE providers
        SET total_earnings = total_earnings + ${booking[0].price}
        WHERE id = ${booking[0].provider_id}
      `;
    }

    return Response.json({ booking: result[0] });
  } catch (error) {
    console.error("Error updating booking status:", error);
    return Response.json(
      { error: "Failed to update booking status" },
      { status: 500 },
    );
  }
}
