import sql from "@/app/api/utils/sql";

export async function GET(request, { params }) {
  try {
    const { id } = params;

    const reviews = await sql`
      SELECT 
        r.*,
        u.name as customer_name
      FROM reviews r
      JOIN auth_users u ON r.customer_id = u.id
      WHERE r.provider_id = ${id}
      ORDER BY r.created_at DESC
    `;

    return Response.json({ reviews });
  } catch (error) {
    console.error("Error fetching reviews:", error);
    return Response.json({ error: "Failed to fetch reviews" }, { status: 500 });
  }
}
