import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET() {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Check if user is admin
    const userCheck = await sql`
      SELECT role FROM auth_users WHERE id = ${session.user.id}
    `;

    if (!userCheck[0] || userCheck[0].role !== "admin") {
      return Response.json(
        { error: "Forbidden - Admin only" },
        { status: 403 },
      );
    }

    const providers = await sql`
      SELECT 
        p.*,
        u.name,
        u.email
      FROM providers p
      JOIN auth_users u ON p.user_id = u.id
      ORDER BY p.created_at DESC
    `;

    return Response.json({ providers });
  } catch (error) {
    console.error("Error fetching providers:", error);
    return Response.json(
      { error: "Failed to fetch providers" },
      { status: 500 },
    );
  }
}
