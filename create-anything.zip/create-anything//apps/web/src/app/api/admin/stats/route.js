import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET() {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Check if user is admin
    const userCheck = await sql`
      SELECT role FROM auth_users WHERE id = ${session.user.id}
    `;

    if (!userCheck[0] || userCheck[0].role !== "admin") {
      return Response.json(
        { error: "Forbidden - Admin only" },
        { status: 403 },
      );
    }

    // Get total users
    const totalUsers = await sql`
      SELECT COUNT(*) as count FROM auth_users
    `;

    // Get total providers (approved, pending, rejected)
    const providerStats = await sql`
      SELECT 
        verification_status,
        COUNT(*) as count
      FROM providers
      GROUP BY verification_status
    `;

    // Get total bookings by status
    const bookingStats = await sql`
      SELECT 
        status,
        COUNT(*) as count,
        SUM(price) as revenue
      FROM bookings
      GROUP BY status
    `;

    // Get total revenue
    const totalRevenue = await sql`
      SELECT SUM(price) as total FROM bookings WHERE status = 'completed'
    `;

    // Get recent bookings
    const recentBookings = await sql`
      SELECT 
        b.*,
        c.name as customer_name,
        p.bio as provider_bio,
        pu.name as provider_name
      FROM bookings b
      JOIN auth_users c ON b.customer_id = c.id
      JOIN providers p ON b.provider_id = p.id
      JOIN auth_users pu ON p.user_id = pu.id
      ORDER BY b.created_at DESC
      LIMIT 10
    `;

    return Response.json({
      stats: {
        totalUsers: totalUsers[0].count,
        providerStats,
        bookingStats,
        totalRevenue: totalRevenue[0].total || 0,
      },
      recentBookings,
    });
  } catch (error) {
    console.error("Error fetching admin stats:", error);
    return Response.json({ error: "Failed to fetch stats" }, { status: 500 });
  }
}
